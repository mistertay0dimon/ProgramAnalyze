from ProgramAnalyze import analyze_code, print_results

filepaths = [
    'server.py',
    'templates/index.html',
    'static/script.js'
]

results = analyze_code(filepaths)
print_results(results)
